



/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  
 * Use, duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp. 
 *******************************************************************************/
dojo.provide("com.crane.validation.ir_validation_message");
dojo.require("com.ibm.team.repository.web.client.session.Session");
dojo.require("com.ibm.team.workitem.api.common.WorkItemAttributes");



(function () {
    var getAuthenticatedContributor = com.ibm.team.repository.web.client.session.getAuthenticatedContributor;
    var workItemAttributes = com.ibm.team.workitem.api.common.WorkItemAttributes;


    dojo.declare("com.crane.validation.ir_validation_message", null, {


        getValue: function (attribute, workItem, configuration) {
            let validationMessage = ""

            const workflowAction = {
                Assign: 'ir_workflow.action.a4',
                Reject: 'ir_workflow.action.a2',
                Defer: 'ir_workflow.action.a12',
                Resolve: 'ir_workflow.action.a5',
                "Accept for Verification": 'ir_workflow.action.a9',
                Pass: 'ir_workflow.action.a13',
                Fail: 'ir_workflow.action.a11',
                'Submit to CCB': 'ir_workflow.action.a7'
            }
            const validation = {
                valid: 'validation.literal.l4',
                notValid: 'validation.literal.l2'
            }
            // Compare the input date with the current date return inputDate > currentDate;
            function isFutureDate(dateString) {
                const inputDate = new Date(dateString);
                const currentDate = new Date();
                return inputDate > currentDate;
            }

            let validResult = true;
            const currentUser = getAuthenticatedContributor().itemId;

            // In New State
            if (workItem.getLabel(workItemAttributes.STATE) == 'New') {
                if (workItem.getValue('workflowAction') == workflowAction['Submit to CCB']) {
                    if (workItem.getValue('creator') != currentUser) { validationMessage += "IR Can only be submitted by the Creator \n"; }

                }

            }


            // In IR Review State                                                                                       
            if (workItem.getLabel(workItemAttributes.STATE) == 'IR Review') {

                // Action selected IR Review > Reject
                if (workItem.getValue('workflowAction') == workflowAction['Reject']) {
                    // Require a Comment
                    if (
                        workItem.getValue('internalComments') === null ||
                        workItem.getValue('internalComments').length == 0 ||
                        !workItem.getValue('internalComments').findLast(comment => comment.isNew && comment.content.length > 0)
                    ) { validationMessage += "Comments are required for Reject action.  Click to resolve >> \n" }
                }

                // Action selected IR Review > Defer
                if (workItem.getValue('workflowAction') == workflowAction['Defer']) {
                    // Require a Comment
                    if (
                        workItem.getValue('internalComments') === null ||
                        workItem.getValue('internalComments').length == 0 ||
                        !workItem.getValue('internalComments').findLast(comment => comment.isNew && comment.content.length > 0)
                    ) { validationMessage += "Comments are required for Defer action.  Click to resolve >> \n" }

                    // Make sure that defer_date is in the future
                    const defer_date = workItem.getValue('defer_date');
                    if (defer_date == null || !isFutureDate(defer_date)) {
                        validationMessage += "Defer Date must be in the future\n"
                    }
                }

                // Action selected IR Review > Assign
                if (workItem.getValue('workflowAction') == workflowAction['Assign']) {
                    // Require a Resolver not to be same as Verification Engineer
                    if (workItem.getValue('com.crane.cr_process.resolver') == workItem.getValue('verification_engineer')) {
                        validationMessage += "Resolver cannot be same as Verification Engineer\n"
                    }

                    // Make sure that estimated_completion_date is in the future
                    const estimated_completion_date = workItem.getValue('estimated_completion_date');
                    if (estimated_completion_date == null || !isFutureDate(estimated_completion_date)) {
                        validationMessage += "Estimation Completion Date must be in the future\n"
                    }

                    // Make sure that estimated_verification_date is in the future
                    const estimated_verification_date = workItem.getValue('estimated_verification_date');
                    if (estimated_verification_date == null || !isFutureDate(estimated_verification_date)) {
                        validationMessage += "Estimation Verification Date must be in the future\n"
                    }
                }
            }



            // In the IR Assigned State
            if (workItem.getLabel(workItemAttributes.STATE) == 'IR Assigned') {
                // Require a Resolver not to be same as Verification Engineer
                if (workItem.getValue('com.crane.cr_process.resolver') == workItem.getValue('verification_engineer')) {
                    validationMessage += "Resolver cannot be same as Verification Engineer\n"
                }

                // Make sure that estimated_completion_date is in the future
                const estimated_completion_date = workItem.getValue('estimated_completion_date');
                if (estimated_completion_date && !isFutureDate(estimated_completion_date)) {
                    validationMessage += "Estimation Completion Date must be in the future\n"
                }

                // Make sure that estimated_verification_date is in the future
                const estimated_verification_date = workItem.getValue('estimated_verification_date');
                if (estimated_verification_date && !isFutureDate(estimated_verification_date)) {
                    validationMessage += "Estimation Verification Date must be in the future\n"
                }

                // Action selected IR Assigned > Resolve
                if (workItem.getValue('workflowAction') == workflowAction['Resolve']) {

                    // Require a current user to be a resolver
                    if (workItem.getValue('com.crane.cr_process.resolver') != currentUser) {
                        validationMessage += "Current user must be a Resolver\n"
                    }
                    // Require a Comment
                    if (
                        workItem.getValue('internalComments') === null ||
                        workItem.getValue('internalComments').length == 0 ||
                        !workItem.getValue('internalComments').findLast(comment => comment.isNew && comment.content.length > 0)
                    ) { validationMessage += "Comments are required to continue.  Click to resolve >> \n" }
                }
            }

            // In the IR Resolved State
            if (workItem.getLabel(workItemAttributes.STATE) == 'IR Resolved') {
                // Make sure that estimated_completion_date is in the future
                const estimated_completion_date = workItem.getValue('estimated_completion_date');
                if (estimated_completion_date && !isFutureDate(estimated_completion_date)) {
                    validationMessage += "Estimation Completion Date must be in the future\n"
                }

                // Make sure that estimated_verification_date is in the future
                const estimated_verification_date = workItem.getValue('estimated_verification_date');
                if (estimated_verification_date && !isFutureDate(estimated_verification_date)) {
                    validationMessage += "Estimation Verification Date must be in the future\n"
                }

                // Action selected IR Resolved > Verify
                if (workItem.getValue('workflowAction') == workflowAction['Accept for Verification']) {
                    // Require a current user to be a verification_engineer
                    if (workItem.getValue('verification_engineer') != currentUser) {
                        validationMessage += "Current user must be a Verification Engineer\n"
                    }
                }


                // Require a Resolver not to be same as Verification Engineer
                if (workItem.getValue('com.crane.cr_process.resolver') == workItem.getValue('verification_engineer')) {
                    validationMessage += "Resolver cannot be same as Verification Engineer\n"
                }


            }


            // In the IR Verify State
            if (workItem.getLabel(workItemAttributes.STATE) == 'IR Verify') {

                // Require a Resolver not to be same as Verification Engineer
                if (workItem.getValue('com.crane.cr_process.resolver') == workItem.getValue('verification_engineer')) {
                    validationMessage += "Resolver cannot be same as Verification Engineer\n"
                }

                // Require a current user to be a verification_engineer
                if (workItem.getValue('verification_engineer') != currentUser) {
                    validationMessage += "Current user must be a Verification Engineer\n"
                }

                if (workItem.getValue('workflowAction') == workflowAction['Pass']) {
                    // Validate Checklists and meeting Minutes to not have _TBD_s
                    if (workItem.getValue('checklist').includes('_TBD_')) { validationMessage += "_TBD_ is still in checklist 1\n" }
                    if (workItem.getValue('checklist-2').includes('_TBD_')) { validationMessage += "_TBD_ is still in checklist 2\n" }
                    if (workItem.getValue('checklist-3').includes('_TBD_')) { validationMessage += "_TBD_ is still in checklist 3\n" }
                    if (workItem.getValue('meeting_minutes').includes('_TBD_')) { validationMessage += "_TBD_ is still in meeting minutes\n" }
                    if (workItem.getValue('defects_list').includes('_TBD_')) { validationMessage += "_TBD_ is still in defects list\n" }
                    if (workItem.getValue('checklist') == "") { validationMessage += "Checklist 1 cannot be empty\n" }
                    if (workItem.getValue('checklist') == "Please choose checklist above") { validationMessage += "Checklist 1 cannot be empty\n" }
                }
            }

            // if (workItem.getLabel(workItemAttributes.STATE) == 'IR Verify') {
            //     if (workItem.getValue('checklist').includes('_TBD_')) {
            //         validationMessage += "_TBD_ is still in checklist 1 "
            //     }
            //     if (workItem.getValue('checklist-2').includes('_TBD_')) {
            //         validationMessage += "_TBD_ is still in checklist 2 "
            //     }
            //     if (workItem.getValue('checklist-3').includes('_TBD_')) {
            //         validationMessage += "_TBD_ is still in checklist 3 "
            //     }
            //     if (workItem.getValue('meeting_minutes').includes('_TBD_')) {
            //         validationMessage += "_TBD_ is still in meeting minutes "
            //     }
            //     if (workItem.getValue('defects_list').includes('_TBD_')) {
            //         validationMessage += "_TBD_ is still in defects list "
            //     }
            //     if (workItem.getValue('checklist') == "") {
            //         validationMessage += "Checklist 1 cannot be empty "
            //     }
            //     if (workItem.getValue('checklist') == "Please choose checklist above") {
            //         validationMessage += "Checklist 1 cannot be empty "
            //     }
            //     if (workItem.getValue('verification_engineer') != currentUser) { 
            //         validationMessage += "Current user is not a Verification Engineer"
            //      }

            //     if ( workItem.getValue('com.crane.cr_process.resolver') == currentUser) {
            //         validationMessage += "Verifier cannot be same as Resolver"
            //     }

            // }

            // if (workItem.getLabel(workItemAttributes.STATE) == 'IR Assigned' ||
            //     workItem.getLabel(workItemAttributes.STATE) == 'IR Rework') {
            //     if (
            //         workItem.getValue('internalComments') === null || 
            //         workItem.getValue('internalComments').length == 0 || 
            //         !workItem.getValue('internalComments').findLast(
            //         comment => comment.isNew && comment.content.length > 0)) { 
            //         validationMessage += `Comments are required for "${workItem.getLabel(workItemAttributes.STATE)}"`
            //     }

            // }


            return validationMessage


            // return workItem.getValue(attribute);

        }
    });
})();

