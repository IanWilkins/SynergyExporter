/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2020. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  
 * Use, duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp. 
 *******************************************************************************/
dojo.provide("com.ibm.team.workitem.attribute.numStoryPtsValueProvider");

(function() {
	var doDebug= true; 
    var scriptName= "numericStoryPointsCalculator";
	
dojo.declare("com.ibm.team.workitem.attribute.numStoryPtsValueProvider", null, {

        getValue: function(attribute, workItem, configuration) {
        	// Grab the enumeration label for the Story Points attribute  
			var storyPtsLabel= workItem.getLabel("com.ibm.team.apt.attribute.complexity");
			
			// Declare the numeric Story Points attributes
			var numStoryPts= 0; 
			
			// Set the numeric attribute based on the enumeration label
			numStoryPts= calc(storyPtsLabel, 0);
			
			return numStoryPts;

			function calc(a_label, default_val) {	
				var result= default_val;
		    		switch (a_label) {
					case '1 pt':
						result= 1;
						break;
					case '2 pts':
						result= 2;
						break;
					case '3 pts':
						result= 3;
						break;
					case '5 pts':
						result= 5;
						break;
					case '8 pts':
						result= 8;
						break;
					case '13 pts':
						result= 13;
						break;
					case '20 pts':
						result= 20;
						break;
					case '40 pts':
						result= 40;
						break;
					case '100 pts':
						result= 100;
						break;
			    	}
		    		return result;
			}
        }
	});
})();