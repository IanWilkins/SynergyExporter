

/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  
 * Use, duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp. 
 *******************************************************************************/
dojo.provide("com.craneae.scripts.parent_validation");

// (function() {
//     // Store the original addEventListener method
//     const originalAddEventListener = EventTarget.prototype.addEventListener;
  
//     // Create a list to store registered events
//     const registeredEvents = [];
  
//     // Override addEventListener to track events
//     EventTarget.prototype.addEventListener = function(type, listener, options) {
//       registeredEvents.push({ target: this, type, listener, options });
//       originalAddEventListener.call(this, type, listener, options);
//     };
  
//     // Function to log all registered events
//     window.getRegisteredEvents = function() {
//       return registeredEvents;
//     };
//   })();
  

function searchValueInPath(obj, searchValue) {
    try {
      for (let i = 0; i < obj.length; i++) {
        if (obj[i].linkDTOs) {
          for (let j = 0; j < obj[i].linkDTOs.length; j++) {
            if (obj[i].linkDTOs[j].target) {
              for (let k = 0; k < obj[i].linkDTOs[j].target.attributes.length; k++) {
                if (obj[i].linkDTOs[j].target.attributes[k].value && obj[i].linkDTOs[j].target.attributes[k].value.id === searchValue) {
                  return true;
                }
              }
            }
          }
        }
      }
      return false;
    } catch (e) {
      console.log("Error traversing the object:", e);
      return false;
    }
  }

  function keyExistsInPath(obj, keyName) {
    try {
      for (let i = 0; i < obj.length; i++) {
        if (obj[i].linkDTOs) {
          for (let j = 0; j < obj[i].linkDTOs.length; j++) {
            if (obj[i].linkDTOs[j].target) {
              for (let k = 0; k < obj[i].linkDTOs[j].target.attributes.length; k++) {
                if (obj[i].linkDTOs[j].target.attributes[k].key === keyName) {
                  return true;
                }
              }
            }
          }
        }
      }
      return false;
    } catch (e) {
      console.log("Error traversing the object:", e);
      return false;
    }
  }


var previousState = null;
var parentValidation = true;
var needToSetInterval = true;

// if (needToSetInterval) {
//     setInterval(function() {

//         const element = document.querySelector("div[aria-label='Summary'").
//         // Create the event
//         const event = new Event('change', {
//             bubbles: true,
//             cancelable: true
//         });
        
//         // Dispatch the event
//         element.dispatchEvent(event);
  

//         // const value = window.com.craneae.scripts.parent_validation._meta.hidden.getValue(attribute, workItem, configuration);
//         console.log("Dispatched");
//         needToSetInterval = false;
        
//         // let currentState = null;
//         // if (workItem.getProxy().object.linkTypes.length > 0) {
//             //     currentState = workItem.getProxy().object.linkTypes[0].linkDTOs[0].target.itemId;
//             // }
            
//             // if (currentState !== previousState) {
//                 //     console.log("Object changed:", attribute);
//                 //     previousState = currentState;
//                 //     parentValidation = false;
//             // }
//     }, 1000);

// }
(function() {
    dojo.declare("com.craneae.scripts.parent_validation", null, {

        getValue: function(attribute, workItem, configuration) {

            const validation =  {
                valid: 'validation.literal.l4', 
                notValid: 'validation.literal.l2'
            }
            let result = false;

            let keyFound = keyExistsInPath(workItem.getProxy().object.linkTypes, "workItemType");

            if (keyFound) {
                result = searchValueInPath(workItem.getProxy().object.linkTypes, "wi_change_request_cr");
            } else {
                result = workItem.getProxy().object.linkTypes.some(item => item["id"] === "com.ibm.team.workitem.linktype.parentworkitem")
            }
             
        
      // return workItem.getValue(attribute);
            return result && parentValidation ? validation['valid'] : validation['notValid']

      
        }
    });
})();
