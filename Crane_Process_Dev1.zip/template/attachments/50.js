

/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  
 * Use, duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp. 
 *******************************************************************************/
dojo.provide("com.crane.ValueProvider.checklist");
dojo.require("com.ibm.team.workitem.api.common.WorkItemAttributes");


(function () {
    var WorkItemAttributes = com.ibm.team.workitem.api.common.WorkItemAttributes;

    dojo.declare("com.crane.ValueProvider.checklist", null, {

        getValue: function (attribute, workItem, configuration) {
            const controls = {
                  'checklist': 'com.crane.attribute.select_checklist', 
                  'checklist-2': 'select-checklist-2', 
                  'checklist-3': 'select_checklist3', 
            }
            let value = '';

            if (attribute == "meeting_minutes") {
                if (workItem.getLabel("meeting_form") == 'Fill in Form') {
                    value = meeting_minutes;
                }
            } else if (attribute == "defects_list") {
                if (workItem.getLabel("defect_form") == 'Fill in Form') {
                    value = defects_list;
                }
            } else {
                if (workItem.getValue(attribute) == "" || workItem.getValue(attribute) == "Please choose checklist above") {
                    value = checklists[workItem.getLabel(controls[attribute])];
    
                } else {
                    alert("Checklist field must be cleared before changing the checklist")
                    throw new Error("Aborting value return");
                }
            }

            
    
            value = value.replace(/%project_name%/g, workItem.getLabel(WorkItemAttributes.PROJECT_AREA));
            value = value.replace(/%change_request%/g, workItem.getLabel(WorkItemAttributes.ID));
            value = value.replace(/%producer%/g, workItem.getLabel('com.crane.cr_process.resolver'));
            value = value.replace(/%owner%/g, workItem.getLabel('verification_engineer'));
            value = value.replace(/%date%/g, new Date().toLocaleDateString('en-US'));

            return value;
        }
    });

    var checklists = {
        "Other / Custom Checklist": `
                         CHECKLIST TEMPLATE
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

-----------------------------------------------------------------------------

NOTE: Please update the content of this checklist as needed

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Sample Section 

_TBD_ a. Please replace this sample checklist item and items below with the 
         required content.

_TBD_ b. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
         incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, 
         quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
         Duis aute irure dolor in reprehenderit in voluptate velit esse cillum 
         dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, 
         sunt in culpa qui officia deserunt mollit anim id est laborum.

_TBD_ c. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
         incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, 
         quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
         Duis aute irure dolor in reprehenderit in voluptate velit esse cillum 
         dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, 
         sunt in culpa qui officia deserunt mollit anim id est laborum.

_TBD_ d. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
         incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, 
         quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
         Duis aute irure dolor in reprehenderit in voluptate velit esse cillum 
         dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, 
         sunt in culpa qui officia deserunt mollit anim id est laborum.
         `,
        "Compliance Matrix Checklist": `
                         COMPLIANCE MATRIX CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

-----------------------------------------------------------------------------

NOTE: This checklist applies to the review of the compliance matrix for the 
      stakeholder requirements specified by the problem report. This is not the 
      checklist for document release into PDM. For PDM release use the SYSTEM DOCUMENT 
      INITIAL REVIEW CHECKLIST or SYSTEM DOCUMENT UPDATE REVIEW CHECKLIST in addition 
      to this checklist. 

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Intent to Comply

_TBD_ a. Have all applicable stakeholder requirement been identified as applicable?
         (i.e. the object type attribute is populated correctly for all stakeholder 
         specification statements.)

_TBD_ b. Do all applicable stakeholder requirements have a statement of intent to 
         comply?

_TBD_ c. For any stakeholder requirement that is “Accepted with Clarification", are 
         all assumptions and clarifications described?

_TBD_ d. For any stakeholder requirement that is "Accepted with Deviation" or "Not 
         Accepted", are all deviations described?


2. Compliance Demonstration and Traceability

_TBD_ a. Has the type of all applicable and accepted stakeholder requirements been 
         identified to distinguish process and product requirements?
         (Note: Product requirements are those that drive the design and require 
         flow down to the Crane requirements set.)

_TBD_ b. Have all product stakeholder requirements been flowed down to the child Crane 
         Requirements?

_TBD_ c. Has the means of compliance been identified for all process stakeholder 
         requirements?


3. Final Statement of Compliance

_TBD_ a. Have all applicable and accepted product stakeholder requirements been 
         verified?

_TBD_ b. Have all intent to comply statements been changed to compliance statements?

_TBD_ c. Have all verification failures been reflected in the compliance statements?
    
        `,
        "System Configuration Index Document Checklist": `
                        SYSTEM CONFIGURATION INDEX DOCUMENT CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

---------------------------------------------------------------------------

NOTE: This checklist applies to the review of content that is specific to the System 
      Configuration Index Document (SYCID) per EIS 0501-017. This is not the checklist 
      for document release into PDM. For PDM release use the SYSTEM DOCUMENT INTIAL 
      REVIEW CHECKLIST or SYSTEM DOCUMENT UPDATE REVIEW CHECKLIST in addition to this 
      checklist.

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Configuration Baselines

_TBD_ a. Is the current revision identified and valid for all subject documents?

_TBD_ b. Does the current revision of each subject document correctly call out this 
         SYCID for its reference document revisions?

_TBD_ c. Are all historical revisions identified for all subject documents?

_TBD_ d. Are all of the subject documents added/changed for this SYCID revision under 
         configuration control (baselined, frozen)?

_TBD_ e. Are all of the reference documents under configuration control (baselined, 
         frozen, released)?


2. Completeness

_TBD_ a. For each subject document, is the list of reference documents complete?


3. Correctness

_TBD_ a. For each subject document, is the initial revision of each reference 
         documents correct?

_TBD_ b. For each subject document, are all updated revisions valid (refer to any 
         supporting impact analysis)?

        `,
        "System Document Initial Review Checklist": `
                   SYSTEM DOCUMENT INITIAL REVIEW CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

---------------------------------------------------------------------------

NOTE: This checklist applies to new system document creation, i.e. "Rev -". The 
      GENERAL CONTENT CHECKLIST should be used in addition to this checklist. The 
      appropriate technical content checklist should be used prior to or in addition 
      to this checklist.

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Review Readiness

_TBD_ a. Is the document revision under PDM configuration control?

_TBD_ b. Does the document number on the first/title page match the document 
         record number in PDM?

_TBD_ c. If DOORS is used as the source of data for this document, have the 
         DOORS module(s) been baselined and are the baselines identified?
         (Examples of how baselines may be identified include on the document cover 
         page, in the body of the document, in the TeamOne record, etc.)

_TBD_ d. Have all problem reports associated with this document release (other than 
         this problem report) been concluded?

_TBD_ e. If the System Configuration Index Document (SYCID) is used as the source of 
         data for this document, is the SYCID document revision under PDM 
         configuration control?


2. Document Content/Format

_TBD_ a. Does the document fulfill the scope of the associated problem report(s)?

_TBD_ b. Does the document fulfill the scope of the document described in the program 
         plans?

_TBD_ c. Is the Change Record up to date?

_TBD_ d. For documents not generated from DOORS:
         Is the List of Active Pages (LAP) up to date per EIS 2010-004?

_TBD_ e. Are all pages numbered correctly?

_TBD_ f. Are the Table of Contents, List of Figures, and List of Tables up to date?

_TBD_ g. Does the document have a "Purpose" section and does it describe the 
         reason for creating the document?

_TBD_ h. Does the document have a "Scope" section and does it define the 
         effectivity, or relationship, to the specific configuration of the 
         product?

_TBD_ i. Does the document have a list of applicable documents and is every 
         document in the list referenced in the body of the document?

_TBD_ j. Are all acronyms used in the body of the document listed in the "Acronyms" 
         section?

_TBD_ k. Are all sections populated with content specific to this project?
         (e.g. not marked TBD/TBV/TBC, no content carried over from previously 
         developed items, etc.)?

_TBD_ l. If appendices are used, have they been referenced in the body of the 
         document?

_TBD_ m. For documents not generated from DOORS:
         If appendices are used, does each appendix have a separate title sheet and 
         are the appendices uniquely paginated per EIS 2010-004?

        `,
        "System Document Update Review Checklist": `
                   SYSTEM DOCUMENT UPDATE REVIEW CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

---------------------------------------------------------------------------

NOTE: This checklist applies to system document revisions after initial release, 
      i.e. not "Rev -". The GENERAL CONTENT CHECKLIST should be used in addition to 
      this checklist. If the system document contains significant changes, the 
      appropriate technical content checklist should be used prior to or in addition 
      to this checklist.

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Review Readiness

_TBD_ a. Is the document revision under PDM configuration control?

_TBD_ b. Does the document number on the first/title page match the document record 
         number in PDM?

_TBD_ c. If DOORS is used as the source of data for this document, have the 
         DOORS module(s) been baselined and are the baselines identified?
         (Examples of how baselines may be identified include on the document cover 
         page, in the body of the document, in the TeamOne record, etc.)

_TBD_ d. Have all problem reports associated with this document release (other than 
         this problem report) been concluded?

_TBD_ e. If the System Configuration Index Document (SYCID) is used as the source of 
         data for this document, is the SYCID document revision under PDM 
         configuration control?


2. Impact Assessment

_TBD_ a. Has the impact of these changes to other work products been assessed?
         (e.g. does revision of this document require a revision of another document)


3. Document Content/Format

_TBD_ a. Does the document fulfill the scope of the associated problem report(s)?

_TBD_ b. Does the document fulfill the scope of the document described in the program 
         plans?

_TBD_ c. Does the Change Record list all incorporated problem reports?

_TBD_ d. For documents not generated from DOORS:
         Is the List of Active Pages (LAP) up to date per EIS 2010-004?

_TBD_ e. Are all pages numbered correctly?

_TBD_ f. Are the Table of Contents, List of Figures and List of Tables up to date?

_TBD_ g. Does the document have a "Purpose" section and does it describe the 
         reason for creating the document?

_TBD_ h. Does the document have a "Scope" section and does it define the 
         effectivity, or relationship, to the specific configuration of the 
         product?

_TBD_ i. Does the document have a list of applicable documents and is every 
         document in the list referenced in the body of the document?

_TBD_ j. Are all acronyms used in the body of the document listed in the "Acronyms" 
         section?

_TBD_ k. Are all sections populated with content specific to this project?
         (e.g. not marked TBD, no content carried over from previously developed 
         items, etc.)

_TBD_ l. If appendices are used, have they been referenced in the body of the 
         document?

_TBD_ m. For documents not generated from DOORS:
         If appendices are used, does each appendix have a separate title sheet and 
         are the appendices uniquely paginated per EIS 2010-004?

_TBD_ n. If change bars are present, are they applied correctly to all changes? 
         (NOTE: EIS 2010-004 does not require change bars)

        `,
        "Equipment Configuration Index Document Checklist": `
               EQUIPMENT CONFIGURATION INDEX DOCUMENT CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

---------------------------------------------------------------------------

NOTE: This checklist applies to the review of content that is specific to the 
      Equipment Configuration Index Document (EQCID). This is not the checklist for 
      document release into PDM. For PDM release use the SYSTEM DOCUMENT INITIAL 
      REVIEW CHECKLIST or SYSTEM DOCUMENT UPDATE REVIEW CHECKLIST in addition to this 
      checklist.

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Configuration Baseline

_TBD_ a. Is the end-item equipment fully defined, so that it is reconstructable, 
         including the following information:
         - end-item part number and amendment (if applicable)
         - complete (programmed) end-item parts list hierarchy (with revisions)
         - embedded software configuration items, if not explicitly identified by the 
           end-item parts list hierarchy?
         (Note that the software configuration items may be identified by the Altered 
         Item Description (AID) document.)


2. Configuration Evolution Definition

_TBD_ a. Are all of the changes incorporated into the equipment subsequent to the 
         release of the previous revision of the EQCID identified, including the 
         following information:
         - high level description of the changes
         - problem report or change control order under which the changes were made?

        `,
        "General Content Checklist": `
                          GENERAL CONTENT CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

-----------------------------------------------------------------------------

NOTE: This checklist applies to the content specified by the problem report.

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


_TBD_ a. Are figures, tables and sections correctly named and numbered?

_TBD_ b. Are figures, tables and sections correctly referenced?

_TBD_ c. Is the content free from grammatical and typographical errors?

_TBD_ d. Is the information contained in figures consistent with the other content?

_TBD_ e. Are all terms and units of measure defined/standard and consistent?

_TBD_ f. Are all referenced material and sections present?

_TBD_ g. Does the problem report description and corresponding log match the 
         new/modified content?

        `,
        "Product Similarity Assessment Review Checklist": `
                PRODUCT SIMILARITY ASSESSMENT REVIEW CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

---------------------------------------------------------------------------

NOTE: This checklist applies to the review of content that is specific to the product 
      similarity assessment for verification and qualification per EIS 0504-006. This 
      is not the checklist for document release into PDM. For PDM release use the 
      SYSTEM DOCUMENT INITIAL REVIEW CHECKLIST or SYSTEM DOCUMENT UPDATE REVIEW 
      CHECKLIST in addition to this checklist.

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Configuration Baselines

_TBD_ a. Are all of the baseline product configurations identified by a released 
         artifact that clearly identifies that configuration?
         (e.g. Configuration Index, complete parts list hierarchy (with revisions))

_TBD_ b. Is the new target product configuration identified by a released artifact 
         that clearly identifies that configuration?
         (e.g. Configuration Index, complete parts list hierarchy (with revisions))

_TBD_ c. Is the verification data for the baseline product configurations released?

_TBD_ d. Does the verification data for the identified baseline configuration(s) 
         demonstrate that the original test or analysis verification data was 
         generated for that baseline configuration?
         (i.e. confirm that the baseline product configuration was not verified by 
         similarity)


2. Configuration Evolution Definition

_TBD_ a. Are all of the changes between the baseline product configuration(s) and the 
         new target configurations identified?


3. Assessment

_TBD_ a. Has the impact of all changes been evaluated?

_TBD_ b. Are the assessment conclusions correct and complete?

_TBD_ c. Does the analysis address compliance for all input requirements?

_TBD_ d. Have all non-compliances been dispositioned?

_TBD_ e. Is there sufficient detail such that the analysis is reconstructable and 
         repeatable?

        `,
        "System Requirements Change Checklist": `
                     SYSTEM REQUIREMENTS CHANGE CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

-----------------------------------------------------------------------------

NOTE: This checklist applies to review of one or more new or modified system 
      requirements specified by the problem report. To peer review a group of 
      requirements prior to them being placed under configuration control use the 
      SYSTEM REQUIREMENTS REVIEW CHECKLIST. This is not the checklist for document 
      release into PDM. For PDM release use the SYSTEM DOCUMENT INITIAL REVIEW 
      CHECKLIST or SYSTEM DOCUMENT UPDATE REVIEW CHECKLIST in addition to this 
      checklist.

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Requirements Properties

_TBD_ a. Does each new/modified requirement contain one "shall" statement?

_TBD_ b. Does each new/modified DOORS object have the correct object type?

_TBD_ c. For system requirements (SDD): 
         Is each new/modified requirement properly allocated to an item?

_TBD_ d. Has this problem report been associated with the DOORS object(s) created or 
         modified by this problem report?
         (e.g. DOORS attribute populated with problem report identifier, problem 
         report linked to the DOORS object(s), etc.)


2. Requirements Content

_TBD_ a. Is each new/modified requirement accurate, unambiguous, and sufficiently 
         detailed?

_TBD_ b. Is each new/modified requirement limited to what is needed to express the 
         requirement?

_TBD_ c. Do the new/modified requirements avoid conflict with other requirements?

_TBD_ d. Do the new/modified requirements accurately implement the intent of, and 
         avoid conflict with, the parent requirements?
         (NOTE: For SDD requirements, the compliance status and remarks of the parent 
         requirement(s) should be taken into account. Changes to the Compliance 
         Matrix may be necessary.)

_TBD_ e. Are all new/modified requirements populated with content specific to this 
         project? 
         (e.g. not marked TBD/TBV/TBC, no content carried over from previously 
         developed items, etc.)

_TBD_ f. Is each new/modified requirement justified?
         (i.e. Does each new/modified requirement have a trace to a parent requirement 
         and/or a rationale?)

_TBD_ g. Is the rationale for each new/modified derived requirement correct and 
         complete?

_TBD_ h. Can the new/modified requirements be implemented on the target hardware?

_TBD_ i. Can the new/modified requirements be verified?


3. Safety-Related Requirements

_TBD_ a. Is each new/modified safety requirement consistent with the PSSA? 
         (i.e. Do the requirements address all assumptions of the Preliminary System 
         Safety Assessment (PSSA) upon which Compliance with the quantitative and/or 
         qualitative safety requirements is dependent and/or the development assurance 
         level assessment is dependent?)

_TBD_ b. Is each new/modified safety-related requirement identified as such?
         (i.e. "safety tagged")

_TBD_ c. Does the Rationale for each new/modified safety-related requirement contain a 
         reference to the PSSA that contains the driving assumption?


4. Impact Assessment

_TBD_ a. If the new/modified requirements impact lower level requirements 
         (e.g. HW, SW), has a change request been submitted to update the 
         impacted requirements based on the new/modified system requirement(s)?

_TBD_ b. If the new/modified requirements impact test objectives/procedures, has a 
         change been submitted to update the impacted test objectives/procedures based 
         on the new/modified system requirement(s)?

_TBD_ c. If the new/modified requirements impact the test group, has the test group 
         been notified of the new/modified system requirement(s)?

_TBD_ d. If the new/modified requirements impact the system safety, reliability, and 
         maintainability requirements, has the safety group been notified of the 
         new/modified system requirements?

        `,
        "System Requirements Review Checklist": `
                     SYSTEM REQUIREMENTS REVIEW CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

-----------------------------------------------------------------------------

NOTE: This checklist applies to the review of a collection of system requirements 
      specified by the problem report. This is not the checklist for document release 
      into PDM. For PDM release use the SYSTEM DOCUMENT INITIAL REVIEW CHECKLIST or 
      SYSTEM DOCUMENT UPDATE REVIEW CHECKLIST in addition to this checklist.

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Requirements Properties

_TBD_ a. Does each requirement contain one "shall" statement?

_TBD_ b. Does each DOORS object have the correct object type?

_TBD_ c. For system requirements (SDD):
         Is each requirement properly allocated to an item?


2. Requirements Content

_TBD_ a. Is each requirement stated accurate, unambiguous, and sufficiently detailed?

_TBD_ b. Is each requirement limited to what is needed to express the requirement?

_TBD_ c. Do the requirements avoid conflict with other requirements?

_TBD_ d. Do the requirements accurately implement the intent of, and avoid conflict 
         with, the parent requirements?
         (NOTE: For SDD requirements, the compliance status and remarks of the parent 
         requirement(s) should be taken into account. Changes to the Compliance 
         Matrix may be necessary.)

_TBD_ e. Are all requirements populated with content specific to this project?
         (e.g. not marked TBD/TBV/TBC, no content carried over from previously 
         developed items, etc.)

_TBD_ f. Is each requirement justified?
         (i.e. Does each requirement have a trace to a parent requirement and/or a 
         rationale?)

_TBD_ g. Is the rationale for each derived requirement correct and complete?

_TBD_ h. Can the requirements be implemented on the target hardware?

_TBD_ i. Can the requirements be verified?


3. Safety-Related Requirements

_TBD_ a. Are all safety requirements consistent with the PSSA?
         (i.e. Do the requirements address all assumptions of the Preliminary System 
         Safety Assessment (PSSA) upon which compliance with the quantitative and/or 
         qualitative safety requirements is dependent and/or the development assurance 
         level assessment is dependent?)

_TBD_ b. Are all safety-related requirements identified as such?
         (i.e. "safety tagged")

_TBD_ c. Does the Rationale for each safety-related requirement contain a reference to 
         the PSSA that contains the driving assumption?

        `,
        "System Requirements Validation Review Checklist": `
               SYSTEM REQUIREMENTS VALIDATION REVIEW CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

-----------------------------------------------------------------------------

NOTE: This checklist applies to the validation review of system requirements specified 
      by the problem report. This is not the checklist for document release into PDM. 
      For PDM release use the SYSTEM DOCUMENT INITIAL REVIEW CHECKLIST or SYSTEM 
      DOCUMENT UPDATE REVIEW CHECKLIST in addition to this checklist. 

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Traceability Properties

NOTE: These checks ensure requirements that require traceability have the necessary 
      properties but do not check the quality of the traceability.

_TBD_ a. Does each non-derived requirement have a parent?

_TBD_ b. Does each derived requirement have a rationale?

_TBD_ c. Does each requirement that requires flow-down have a child?


2. Traceability Quality

_TBD_ a. Is it apparent from the traceability and supporting rationale that parent 
         requirements are fully satisfied by their associated children?

_TBD_ b. Are parent requirements (and justification if applicable) appropriate based 
         on the satisfying child requirement(s)?

_TBD_ c. Are child requirements necessary based on the parent requirement(s) they 
         satisfy or, for derived requirements, their associated rationale?

_TBD_ d. For stakeholder requirements:
         Has every accepted stakeholder product requirement been correctly and 
         completely captured by its child (Crane) requirements?

_TBD_ e. For system requirements (SDD/ORD):
         Is each requirement allocated to the correct item(s) based on its child 
         requirements?

_TBD_ f. Are assumptions, if applicable, adequately defined and addressed?

        `,
        "System Accomplishment Summary Checklist": `
                 SYSTEM ACCOMPLISHMENT SUMMARY CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

-----------------------------------------------------------------------------

NOTE: This checklist applies to the review of content that is specific to the System 
      Accomplishment Summary (SYAS). This is not the checklist for document release 
      into PDM. For PDM release use the SYSTEM DOCUMENT INITIAL REVIEW CHECKLIST or 
      SYSTEM DOCUMENT UPDATE REVIEW CHECKLIST in addition to this checklist.

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. System Overview

_TBD_ a. Is there an overview of the system with a high level description of the 
         following?
         - the system architecture
         - the system interfaces
         - the key functions
         - any changes relative to the system as described in the SYDP

_TBD_ b. Are any/all changes to the high level design relative to the SYDP described?


2. System Development Compliance with SYDP

_TBD_ a. Is the applied system life cycle described, with differences from the 
         proposed life cycle in the SYDP explained?

_TBD_ b. Is the produced system life cycle data identified with a description of the 
         following?
         - the identification, version, and release status of the life cycle data 
           items
         - a description of the relationship between any life cycle data items
         - a description of any differences from the SYDP

_TBD_ c. Does the SYAS provide sufficient evidence of compliance with the SYDP?

_TBD_ d. Have all SYDP deviations been identified?


2. Reliability and Safety Development Compliance with RPPL

_TBD_ a. Is the applied reliability, maintainability, and safety life cycle described, 
         with differences from the proposed life cycle in the RPPL explained?

_TBD_ b. Is the produced reliability, maintainability, and safety life cycle data 
         identified with a description of the following:?
         - the identification, version, and release status of the life cycle data 
           items
         - a description of the relationship between any life cycle data items
         - a description of any differences from the RPPL

_TBD_ c. Does the SYAS provide sufficient evidence of compliance with the RPPL?

_TBD_ d. Have all RPPL deviations been identified?


2. Open Problem Reports

_TBD_ a. Are all open/deferred problem reports been identified?
         Note: problem reports may be identified directly within the SYAS or by 
         identifying the life cycle data item that identifies all of the open problem 
         reports.

_TBD_ b. Have all open/deferred problem reports been assessed for functional and 
         safety impact?

        `,
        "System Test Script Checklist": `
                         SYSTEM TEST SCRIPT CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

--------------------------------------------------------------------------

NOTE: This checklist applies to the review of system test scripts.

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Configuration Management

_TBD_ a. Are all test scripts under configuration control?
         (NOTE: This includes any test scripts executed by a test script under review)


2. Test Script Content

_TBD_ a. Are comments detailed enough to support review and maintenance of the test 
         script?

_TBD_ b. Are comments complete, correct, and understandable?

_TBD_ c. Does the test script accurately implement the associated test objective(s)?

_TBD_ d. Does the test script run to completion without error and with expected 
         results that match the requirements and test design (i.e. complete without 
         failure)?

        `,
        "System Verification Test Procedure Checklist": `
                 SYSTEM VERIFICATION TEST PROCEDURE CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

-----------------------------------------------------------------------------

NOTE: This checklist applies to review of the technical content of the System 
      Verification Test Procedure (SYVTP) specified by the problem report. This is not 
      the checklist for document release into PDM. For PDM release use the SYSTEM 
      DOCUMENT INITIAL REVIEW CHECKLIST or SYSTEM DOCUMENT UPDATE REVIEW CHECKLIST in 
      addition to this checklist.

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Verification Test Procedure Properties

_TBD_ a. Does each DOORS object have the correct object type defined?

_TBD_ b. Does each requirements based test objective trace to one or more 
         requirements?

_TBD_ d. Is each test procedure associated with one or more test objectives?

_TBD_ e. Is each test case associated with one test procedure?


2. Verification Test Procedure Content

_TBD_ a. Are test data recording methods and redline authority defined?

_TBD_ b. Are the requirements allocated to the system verification process verified 
         per their associated verification method?

_TBD_ c. If the verification method is by test, does each test procedure have clear 
         set up instructions, listing the necessary test equipment, and describing any 
         special test configuration/initialization as applicable?

_TBD_ d. Does each test procedure accurately implement the associated test 
         objective(s)?

_TBD_ e. Does each test procedure/case have expected results with pass/fail criteria?

_TBD_ f. If the verification method is by test, are the test procedure steps clear 
         enough to allow the test to be repeated?

_TBD_ g. If the verification method is by test and has an associated test script, has 
         the test script been reviewed?

_TBD_ h. If the verification method is not by test, is the verification procedure 
         sufficiently detailed?

_TBD_ i. Have redundant verification procedures/cases been avoided?

        `,
        "System Verification Test Report Checklist": `
                  SYSTEM VERIFICATION TEST REPORT CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

-----------------------------------------------------------------------------

NOTE: This checklist applies to the review of the technical content of the System 
      Verification Test Report (SYVTR) specified by the problem report. This is not 
      the checklist for document release into PDM. For PDM release use the SYSTEM 
      DOCUMENT INITIAL REVIEW CHECKLIST or SYSTEM DOCUMENT UPDATE REVIEW CHECKLIST in 
      Addition to this checklist.

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Verification Test Report Content

_TBD_ a. Has the configuration of the unit under test (UUT) been identified and 
         referenced consistently for each conducted test?
         (NOTE: Include the HW and SW part numbers)

_TBD_ b. Has the configuration of test equipment been identified and referenced 
         consistently for each conducted test?
         (NOTE: Include the HW and SW part numbers, release versions, calibration 
         dates)

_TBD_ c. Have the date(s) and personnel conducting the test procedure been 
         recorded?

_TBD_ d. Have test logs been included in the test report?

_TBD_ e. If the verification method is by test, have results been logged for each 
         verifying step of the test procedure in the test results?

_TBD_ f. If the verification method is other than test, have analysis or review 
         results been explained with a conclusion in or referenced by the report?

_TBD_ g. If the test failed, is there a summary of discrepancies, corrective action 
         and problem report for the resolution?

_TBD_ h. Have all redlines been included in the report per the SYVTP redline authority 
         process?

_TBD_ i. Have the processes of Quality and Customer notification and witnessing 
         been followed per the SYVTP when conducting the test?

_TBD_ j. Have all test logs been included in the report?

        `,
        "System Requirements Verification Matrix Checklist": `
              SYSTEM REQUIREMENTS VERIFICATION MATRIX CHECKLIST
                             Version: <TBD>

PROJECT NAME:  %project_name%

CHANGE NUMBER: %change_request%

PRODUCER:      %producer%

REVIEWER:      %owner%

-----------------------------------------------------------------------------

NOTE: This checklist applies to the review of the verification matrix of the system 
      requirements specified by the problem report. This is not the checklist for 
      document release into PDM. For PDM release use the SYSTEM DOCUMENT INITIAL 
      REVIEW CHECKLIST or SYSTEM DOCUMENT UPDATE REVIEW CHECKLIST in addition to this 
      checklist.

      List all discrepancies in the defect list.

      Change "TBD" to Y, N or N/A. Every N or N/A answer must have justification.


1. Verification Method and Verification Activity Allocation

_TBD_ a. Does each requirement have at least one Verification Method allocated?

_TBD_ b. Does each requirement have at least one Verification Activity allocated?

_TBD_ c. Are the allocated Verification Activities consistent with the allocated 
         Verification Methods?

_TBD_ d. Is each requirement verifiable by its allocated Verification Methods and 
         Verification Activities?

_TBD_ e. For each requirement, if more than one Verification Method or Verification 
         Activity is allocated, is the intended coverage of each described?

_TBD_ f. For each requirement, if more than one Verification Method or Verification 
         Activity is allocated, does the combined set of Verification Methods and 
         Verification Activities provide full coverage for that requirement?


2. Test Procedure Traceability

_TBD_ a. Does each requirement trace to at least one verification procedure?

_TBD_ b. For each requirement, are the traced verification procedures consistent with 
         the allocated Verification Methods and Verification Activities?

_TBD_ c. Is each requirement fully verified by its traced verification procedures?

        `
    }

    var meeting_minutes = `
            PEER REVIEW MEETING MINUTES
                  Version: 1

PROJECT NAME: %project_name%
PROBLEM ID:   %change_request%
RESOLVER:     %producer%
VERIFIER:     %owner%
REVIEW DATE:  %date%

REVIEW ATTENDEES: _TBD_

REVIEWED PRODUCTS WITH REVISIONS/BASELINES: _TBD_
%cv_list%


LIST OF ALL SOURCE/PARENT DOCUMENTS WITH REVISIONS: _TBD_

-----------------------------------------------------------------------
START ACTION ITEMS: .............................. STATUS:(Open/Closed)
_TBD_
End ACTION ITEMS.

=======================================================================

    `;

    var defects_list = `
                      WORK PRODUCT DEFECT LIST
                              Version: 1

PROJECT NAME: %project_name%
PROBLEM ID:   %change_request%
RESOLVER:     %producer%
VERIFIER:     %owner%
REVIEW DATE:   %date%


START DEFECTS:
_TBD_
END DEFECTS.

======= Defect Identification Instructions: ========
Group defects by file/document name(s) & version.
Number defects and include unambiguous defect location, clear 
description, and the associated checklist item(s).

=======================================================================
    `;
})();

