

/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  
 * Use, duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp. 
 *******************************************************************************/
dojo.provide("com.crane.Condition.Readonly.meeting.minutes");

(function() {
    dojo.declare("com.crane.Condition.Readonly.meeting.minutes", null, {

        matches: function(workItem, configuration) {

            return workItem.getValue('meeting_minutes').includes('_TBD_');

        }

    });
})();
