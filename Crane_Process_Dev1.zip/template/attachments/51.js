

/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  
 * Use, duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp. 
 *******************************************************************************/
dojo.provide("com.crane.scripts.checklist_history");
dojo.require("com.ibm.team.repository.web.client.session.Session");

var originalValue = {}

function replaceHTMLEntitiesWithNewlines(str) {
    // Replace &nbsp; with a space 
    let tempStr = str.replace(/&nbsp;/g, ' ');
    // Replace <br> with \n 
    tempStr = tempStr.replace(/<br\s*\/?>/gi, '\n');
    // If there are other HTML entities, you can decode them as well 
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = tempStr;
    return tempDiv.textContent || tempDiv.innerText || "";
}

// Create a function to show a custom alert with Yes/No buttons
function showAlert(message, yesCallback, noCallback) {
    // Create the modal container
    const modal = document.createElement('div');
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.width = '100%';
    modal.style.height = '100%';
    modal.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '1000';

    // Create the modal content
    const modalContent = document.createElement('div');
    modalContent.style.backgroundColor = '#fff';
    modalContent.style.padding = '20px';
    modalContent.style.borderRadius = '5px';
    modalContent.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
    modal.appendChild(modalContent);

    // Add the message to the modal content
    const messageElement = document.createElement('p');
    messageElement.innerText = message;
    modalContent.appendChild(messageElement);

    // Create the Finalize button
    const yesButton = document.createElement('button');
    yesButton.innerText = 'Finalize';
    yesButton.style.marginRight = '10px';
    yesButton.onclick = function () {
        document.body.removeChild(modal);
        if (yesCallback) yesCallback();
    };
    modalContent.appendChild(yesButton);

    // Create the Cancel button
    const noButton = document.createElement('button');
    noButton.innerText = 'Cancel';
    noButton.onclick = function () {
        document.body.removeChild(modal);
        if (noCallback) noCallback();
    };
    modalContent.appendChild(noButton);

    // Append the modal to the body
    document.body.appendChild(modal);
}

document.querySelectorAll('input[dojoattachpoint="_inputElement"]').forEach((radio) => {
    radio.addEventListener('change', (event) => {

        const radioValues = {
            "Draft": "checklist_status_enum.literal.l2",
            "Final": "checklist_status_enum.literal.l4",
        }


        if (event.target.value == radioValues["Draft"]) {

            showAlert('Please confirm that you want to finalize this checklist. Current checklist will be saved to permanent history', function () {
                console.log("Confirmed checklist finalization")
            }, function () {
                // Cancel
                document.querySelector(`input[value="${radioValues["Final"]}"]`).checked = true
                event.target.checked = false
                throw new Error("Aborting value return");
            });
        }
    });
});

(function () {
    var getAuthenticatedContributor = com.ibm.team.repository.web.client.session.getAuthenticatedContributor;



    dojo.declare("com.crane.scripts.checklist_history", null, {

        getValue: function (attribute, workItem, configuration) {

            // save originalValue to global variable, do nothing otherwise
            if (originalValue[attribute] === undefined || originalValue[attribute] === null) {
                originalValue[attribute] = workItem.getValue(attribute)
                // originalValue[attribute] = originalValue[attribute] === null ? "" : workItem.getValue(attribute)

            }



            const checklists = {
                'checklist1_history': { "checklist_value": 'checklist', "checklist_status": "checklist1_status2" },
                'checklist2_history': { "checklist_value": 'checklist-2', "checklist_status": "checklist2_status" },
                'checklist3_history': { "checklist_value": 'checklist-3', "checklist_status": "checklist3_status" },
                'meeting.minutes.history': { "checklist_value": 'meeting_minutes', "checklist_status": "meeting.minutes.status" },
                'defect.history': { "checklist_value": 'defects_list', "checklist_status": "defect.status" },
            }

            const checklist = checklists[attribute]

            let currentValue = workItem.getValue(attribute);
            var returnValue = "";

            if (workItem.getLabel(checklist["checklist_status"]) == "Final") {
                const currentDateTime = new Date();
                const formattedDateTime = currentDateTime.toLocaleString(
                    'en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: true
                });

                currentValue = `
============================================
Update by: ${getAuthenticatedContributor().name}
Date / Time: ${formattedDateTime}
-----------------------------------------------------------------------------


${replaceHTMLEntitiesWithNewlines(workItem.getValue(checklist["checklist_value"]))}
${(currentValue !== undefined && currentValue !== null) ? replaceHTMLEntitiesWithNewlines(currentValue) : ""}
`
// ${replaceHTMLEntitiesWithNewlines(originalValue[attribute])}
                returnValue = replaceHTMLEntitiesWithNewlines(currentValue);
            } else {
                returnValue = replaceHTMLEntitiesWithNewlines(originalValue[attribute]);
            }

            delete originalValue[attribute];
            return returnValue;
        }
    });
})();
