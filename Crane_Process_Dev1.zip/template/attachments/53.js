

/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  
 * Use, duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp. 
 *******************************************************************************/
dojo.provide("com.craneae.script.defaultValue.customId");
dojo.require("com.ibm.team.workitem.api.common.WorkItemAttributes");


(function() {
    var WorkItemAttributes = com.ibm.team.workitem.api.common.WorkItemAttributes;


    dojo.declare("com.craneae.script.defaultValue.customId", null, {

        getDefaultValue: function(attribute, workItem, configuration) {
                
            // return workItem.getValue(attribute);
            var result = workItem.getValue(WorkItemAttributes.ID);
            // return `${(WorkItemAttributes.PROJECT_AREA)}#${WorkItemAttributes.ID}`;
            // return "TEST";
            return result;
            
        }
    });
})();
