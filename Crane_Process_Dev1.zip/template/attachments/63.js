

/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  
 * Use, duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp. 
 *******************************************************************************/
dojo.provide("com.craneae.script.defaultValue.projectId");
dojo.require("com.ibm.team.workitem.api.common.WorkItemAttributes");


(function() {
    var WorkItemAttributes = com.ibm.team.workitem.api.common.WorkItemAttributes;

    dojo.declare("com.craneae.script.defaultValue.projectId", null, {

        getValue: function(attribute, workItem, configuration) {
                
            return `${workItem.getLabel(WorkItemAttributes.PROJECT_AREA)}#${workItem.getLabel(WorkItemAttributes.ID)}`;
            
        }
    });
})();
