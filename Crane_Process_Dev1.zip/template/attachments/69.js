

/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  
 * Use, duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp. 
 *******************************************************************************/
dojo.provide("com.crane.Condition.Readonly.checklist");

(function() {
    dojo.declare("com.crane.Condition.Readonly.checklist", null, {

        matches: function(workItem, configuration) {

            return workItem.getValue('checklist-2').includes('_TBD_');

        }

    });
})();
