

/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  
 * Use, duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp. 
 *******************************************************************************/
dojo.provide("com.crane.scripts.readonly-checklist2-status");

(function() {
    dojo.declare("com.crane.scripts.readonly-checklist2-status", null, {

        matches: function(workItem, configuration) {
            let errorsPresent = false;
            if (workItem.getValue('checklist-2').includes('_TBD_')) { errorsPresent = true; }

            return errorsPresent ? true : false;  // if errors present, return 'true', so the widget is set to read-only
        }

    });
})();
