dojo.provide("crane.providers.FiledAgainstValueSet");

dojo.require("com.ibm.team.workitem.api.common.WorkItemAttributes");
dojo.require("dojo.string");

(function() {
var WorkItemAttributes= com.ibm.team.workitem.api.common.WorkItemAttributes;

dojo.declare("crane.providers.FiledAgainstValueSet", null, {

    getValueSet: function(attributeId, workItem, configuration) {
    
        var tags= workItem.getValue(WorkItemAttributes.FILED_AGAINST);
        var severityOptions= [];
        
        if (tags.indexOf("important") === -1) {
            severityOptions.push("severity.literal.l1"); // Unclassified
            severityOptions.push("severity.literal.l2"); // Minor
            severityOptions.push("severity.literal.l3"); // Normal
        }
        
        severityOptions.push("severity.literal.l4"); // Major
        severityOptions.push("severity.literal.l5"); // Critical
        severityOptions.push("severity.literal.l6"); // Blocker

        return severityOptions;
    }
});