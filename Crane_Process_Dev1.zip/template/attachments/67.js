

/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2011. All Rights Reserved.
 *
 * Note to U.S. Government Users Restricted Rights:  
 * Use, duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp. 
 *******************************************************************************/
dojo.provide("com.crane.Condition.Readonly.checklist");
dojo.require("com.ibm.team.workitem.api.common.WorkItemAttributes");


(function() {
    var WorkItemAttributes = com.ibm.team.workitem.api.common.WorkItemAttributes;

    dojo.declare("com.crane.Condition.Readonly.checklist", null, {

        matches: function(workItem, configuration) {

            if (workItem.getLabel(WorkItemAttributes.STATE) == "IR Verify") {
                
                let checklists = [
                    workItem.getValue('checklist').includes('_TBD_'), // true/false
                    workItem.getValue('checklist-2').includes('_TBD_'),
                    workItem.getValue('checklist-3').includes('_TBD_'),
                    workItem.getValue('checklist') == "" // true/false
                ] // [false, false, true]
                
                return checklists.some(Boolean)  //Boolean (true) == true
            }

        }

    });
})();
