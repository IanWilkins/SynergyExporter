dojo.provide("jazz.crane.workitems.Condition.CR_Read-Only-Investigate");

dojo.require("com.ibm.team.workitem.api.common.WorkItemAttributes");

(function() {
var WorkItemAttributes= com.ibm.team.workitem.api.common.WorkItemAttributes;

dojo.declare("jazz.crane.workitems.Condition.CR_Read-Only-Investigate", null, {

    matches: function(workItem, configuration) {
        var state= workItem.getValue(WorkItemAttributes.STATE);
        console.log(typeof(state))
        return (state === "cr_workflow.state.s5"); // Investigate
    }
});
})();