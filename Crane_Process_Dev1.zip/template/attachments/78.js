

dojo.provide("jazz.crane.workitems.providers.Resolver_Value");

dojo.require("com.ibm.team.workitem.api.common.WorkItemAttributes");
dojo.require("dojo.date");
dojo.require("dojo.date.stamp");

(function() {
var WorkItemAttributes= com.ibm.team.workitem.api.common.WorkItemAttributes;

dojo.declare("jazz.crane.workitems.providers.Resolver_Value", null, {

 getValue: function(attributeId, workItem, configuration) {

 // Get the Created By, Current State, Owner
 var currentAttribute = workItem.getValue(attributeId);
 var createdBy = workItem.getValue(WorkItemAttributes.CREATOR);
 var state = workItem.getValue(WorkItemAttributes.STATE);
 var OwnedBy = workItem.getValue(WorkItemAttributes.OWNER);
 
 // Investigate = cr_workflow.state.s5
 // CR CCB Review = cr_workflow.state.s2
 // Defer = cr_workflow.state.s6
 // Reject = cr_workflow.state.s4
 // Assign = cr_workflow.state.s8
 // Conclude = cr_workflow.state.s3
 // New = cr_workflow.state.s1



if ((state === "cr_workflow.state.s3")) { // Conclude
 return OwnedBy;
} else {
 		return currentAttribute; 
 	}

}});
})();

