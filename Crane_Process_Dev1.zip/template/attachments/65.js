dojo.provide("jazz.crane.workitems.Condition.ReadOnly-IR-Resolved");

dojo.require("com.ibm.team.workitem.api.common.WorkItemAttributes");
 
dojo.require("com.ibm.team.repository.web.client.session.Session"); 

(function() {
var WorkItemAttributes= com.ibm.team.workitem.api.common.WorkItemAttributes;
var getAuthenticatedContributor = com.ibm.team.repository.web.client.session.getAuthenticatedContributor;

dojo.declare("jazz.crane.workitems.Condition.ReadOnly-IR-Resolved", null, {

    //matches: function(workItem, configuration) {
    //    var state= workItem.getValue(WorkItemAttributes.STATE);
    //    console.log(typeof(state))
    //    return (state === "ir_workflow.state.s4"); // Resolved
    //}
     
     matches : function(workItem, configuration) { 
  		var loggedInUser = getAuthenticatedContributor().itemId;
  		var action = configuration.getWorkflowAction();
  		var resolver = workItem.getValue('com.crane.cr_process.resolver'); 
  		// console.log((workItem.getLabel(WorkItemAttributes.STATE)));
  		// console.log(action);
  		// console.log((loggedInUser));
  		// console.log((resolver));
  		if (action == "ir_workflow.action.a5") {
  			value_of = (loggedInUser != resolver)
  			// console.log(value_of);
  			var result = (loggedInUser != resolver);
  			return result;
  		} 
     } 
});
})();